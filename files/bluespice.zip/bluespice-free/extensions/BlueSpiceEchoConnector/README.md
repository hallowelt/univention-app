# BlueSpiceEchoConnector

Needs BSF change:
https://gerrit.wikimedia.org/r/#/c/341984/