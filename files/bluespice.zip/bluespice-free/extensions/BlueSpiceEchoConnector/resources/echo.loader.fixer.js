(function( mw ) {
	mw.echo.ui.messageWidget = {
		fetchUnreadCountFromApi: function() {
			return 0;
		}
	}
	mw.echo.ui.alertWidget = {
		fetchUnreadCountFromApi: function() {
			return 0;
		}
	}
})( mediaWiki );

