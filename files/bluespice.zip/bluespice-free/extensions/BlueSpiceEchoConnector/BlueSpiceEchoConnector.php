<?php

wfLoadExtension ( 'BlueSpiceEchoConnector' );
