<?php
wfLoadExtension( 'BlueSpiceDistributionConnector' );
