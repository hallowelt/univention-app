# mediawiki-extension-EditNotify
EditNotify is an extension to MediaWiki that allows users to receive notification for page editing or creation. The extension makes use of Echo extension to notify the users. 

You can find more about the extension at https://www.mediawiki.org/wiki/Extension:EditNotify
