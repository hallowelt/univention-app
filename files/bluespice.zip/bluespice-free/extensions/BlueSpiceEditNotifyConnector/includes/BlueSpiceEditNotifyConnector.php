<?php

class BlueSpiceEditNotifyConnector {

	static $tableName = "bs_editnotifyconnector";

	/**
	 *
	 * @var array available action types with labels
	 */
	static $arrActions = array( //labels will not be used
		"create" => "Creation",
		"edit" => "Edit to existing pages"
	);

	/**
	 *
	 * @var string prefix
	 */
	static $prefixNamespace = "notify-namespace-selectionpage-";

	/**
	 *
	 * @var string prefix
	 */
	static $prefixCategory = "notify-category-selectionpage-";

	/**
	 * change echo notification formatter to bluespice custom version before editnotify process notifications
	 * @global array $wgExtensionFunctions
	 */
	public static function onRegistry() {
		global $wgExtensionFunctions;
		$wgExtensionFunctions[] = function() {
			global $wgHooks;
			$wgHooks[ 'BeforeCreateEchoEvent' ][] = "BlueSpiceEditNotifyConnector::onBeforeCreateEchoEvent";
		};
		global $wgEditNotifyAlerts;
		$wgEditNotifyAlerts = [];
	}

	/**
	 * register notifications for editnotify, should be included / started before same hook call of editnotify
	 * @param array $echoNotifications
	 * @param array $echoNotificationCategories
	 */
	public static function onBeforeCreateEchoEvent( &$echoNotifications, $echoNotificationCategories ) {
		foreach ( $echoNotifications as $key => $val ) {
			if ( preg_match( '#^edit-notify#', $key ) === 1 ) {
				$val[ 'formatter-class' ] = "BsNotificationsFormatter";
				$echoNotifications[ $key ] = $val;
			}
		}
		return true;
	}

	/**
	 *
	 * @return array converted column options from $arrActions for checkmatrix
	 */
	public static function getColumns() {
		$arrColumns = array();
		foreach ( self::$arrActions as $sKey => $oVal ) {
			$arrColumns[ wfMessage( $sKey )->text() ] = "page-" . $sKey;
		}
		return $arrColumns;
	}

	/**
	 * Hooks/GetPreferences
	 *
	 * make user options available to set namespace and category notifications
	 * per default categories are hidden and can be activated over config setting
	 * "$wgBlueSpiceEditNotifyConnectorShowCategories = true" in LocalSettings.php
	 *
	 * https://www.mediawiki.org/wiki/Manual:Hooks/GetPreferences
	 *
	 * @param User $user
	 * @param array $preferences
	 * @return boolean
	 */
	public static function onGetPreferences( User $user, array &$preferences ) {

		$requestContext = RequestContext::getMain();
		$contLang = $requestContext->getLanguage();

		//Add namespace selection matrix
		$arrNamespaces = array();

		foreach ( $contLang->getFormattedNamespaces() as $ns => $title ) {
			if ( $ns > 0 ) {
				$arrNamespaces[ $title ] = $ns;
			} elseif ( $ns == 0 ) {
				$arrNamespaces[ 'Main' ] = $ns;
			}
		}

		$preferences[ 'notify-namespace-selection' ] = array(
			'type' => 'checkmatrix',
			'section' => 'echo/namespace-notifications',
			'help-message' => 'tog-help-notify-namespace-selection', // a system message (optional)
			'rows' => $arrNamespaces,
			'columns' => self::getColumns()
		);

		return true;
	}

	/**
	 * save namespace notification settings in seperate table
	 * @param User $user
	 * @param array $options
	 * @return boolean handover to next call
	 */
	public static function onUserSaveOptions( User $user, array &$options ) {
		$dbw = wfGetDB( DB_MASTER );
		//remove all namespace settings for current user from editnotifyconnector table
		$dbw->delete( self::$tableName, array( "enc_username" => $user->getName() ) );
		//set editnotifyconnector entries for current user
		$nsNotifyOptions = array_filter( $options, function( $key ) {
			if ( strpos( $key, 'notify-namespace-selection' ) === 0 ) {
				return true;
			} else {
				return false;
			}
		}, ARRAY_FILTER_USE_KEY );
		foreach ( $nsNotifyOptions as $sKey => $sValue ) {
			$arrKey = explode( "-", $sKey );
			$action = $arrKey[ 3 ];
			$nsId = $arrKey[ 4 ];
			if ( $sValue ) {
				$dbw->insert(
					self::$tableName,
					array(
						"enc_ns_id" => $nsId,
						"enc_username" => $user->getName(),
						"enc_action" => $action
					)
				);
			}
		}

		return true;
	}

	/**
	 * append content on global settings "$wgEditNotifyAlerts" for editnotify
	 * from database for namespace of current page, lookup user settings with maching
	 * namespace notification settings
	 *
	 * @global type $wgContLang
	 * @global type $wgEditNotifyAlerts
	 * @global type $wgBlueSpiceEditNotifyConnectorShowCategories
	 * @param WikiPage $wikiPage
	 * @param User $user
	 * @param type $content
	 * @param type $summary
	 * @param type $isMinor
	 * @param type $isWatch
	 * @param type $section
	 * @param type $flags
	 * @param type $status
	 * @return boolean
	 */
	public static function onPageContentSave( WikiPage &$wikiPage, &$user, &$content, &$summary, $isMinor, $isWatch, $section, &$flags, &$status ) {

		$requestContext = RequestContext::getMain();
		$contLang = $requestContext->getLanguage();

		global $wgEditNotifyAlerts;

		$wgEditNotifyAlerts = array();

		$nsID = $wikiPage->getTitle()->getNamespace();
		$arrNamespaces = $contLang->getFormattedNamespaces();
		$nsTitle = $arrNamespaces[ $nsID ];

		$dbr = wfGetDB( DB_SLAVE );

		//set config for namespaces
		foreach ( self::$arrActions as $oKey => $oVal ) {
			$arrNSNotifyConfig = array();
			$arrNSNotifyConfig[ "namespace" ] = $nsTitle;
			$arrNSNotifyConfig[ "action" ] = $oKey;
			//This crashes, because DynamicPageList creates a page within the
			//first installation before this table even exists!
			try {
				//get users with abo for current namespace and action combination
				$res = $dbr->select(
				  array( self::$tableName ),
				  array( 'enc_username' ),
				  array( 'enc_ns_id' => $nsID, 'enc_action' => $oKey )
				);
				$arrUser = array();
				foreach ( $res as $row ) {
					$arrUser[] = $row->enc_username;
				}
				$arrNSNotifyConfig[ "users" ] = $arrUser;

				$wgEditNotifyAlerts[] = $arrNSNotifyConfig;
			} catch ( Exception $e ) {
				error_log( $e->getMessage() );
			}
		}

		return true;
	}

	/**
	 *
	 * @param DatabaseUpdater $updater
	 * @return boolean
	 */
	public static function onLoadExtensionSchemaUpdates( DatabaseUpdater $updater ) {
		$updater->addExtensionTable( self::$tableName, __DIR__ . "/../db/editnotifyconnector.sql" );
		return true;
	}

}
