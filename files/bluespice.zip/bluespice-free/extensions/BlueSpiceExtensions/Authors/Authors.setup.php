<?php
wfLoadExtension( 'BlueSpiceExtensions/Authors' );