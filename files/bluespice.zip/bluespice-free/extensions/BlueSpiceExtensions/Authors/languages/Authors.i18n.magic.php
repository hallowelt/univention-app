<?php
$magicWords = array();

$magicWords['en'] = array(
	'bs_noauthors' => array( 0, '__NOAUTHORS__', '__NO_AUTHORS__' ),
);

$magicWords['de'] = array(
	'bs_noauthors' => array( 0, '__KEINEAUTOREN__', '__KEINE_AUTOREN__' ),
);