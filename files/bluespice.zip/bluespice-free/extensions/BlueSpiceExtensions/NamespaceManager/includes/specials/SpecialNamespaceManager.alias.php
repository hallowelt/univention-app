<?php
$specialPageAliases = array();

/** English */
$specialPageAliases['en'] = array(
	'NamespaceManager' => array( 'NamespaceManager', 'Namespace Manager' ),
);

/** German (Deutsch) */
$specialPageAliases['de'] = array(
	'NamespaceManager' => array( 'NamespaceManager', 'Namespace Manager', 'Namensraumverwaltung', 'Namensraum Verwaltung' ),
);
