ALTER TABLE /*$wgDBprefix*/bs_namespacemanager_backup_revision ADD rev_sha1 text NOT NULL DEFAULT '0';
