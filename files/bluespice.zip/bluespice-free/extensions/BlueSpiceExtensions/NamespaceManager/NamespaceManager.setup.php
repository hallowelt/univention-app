<?php
wfLoadExtension( 'BlueSpiceExtensions/NamespaceManager' );