<?php

wfLoadExtension( 'BlueSpiceExtensions/ArticleInfo' );