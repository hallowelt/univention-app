<?php
$magicWords = array();

$magicWords['en'] = array(
	'bs_noarticleinfo' => array( 0, '__NOARTICLEINFO__', '__NO_ARTICLEINFO__' ),
);
