-- Add sb_page_id column indexC
CREATE INDEX /*i*/sb_page_id ON /*$wgDBprefix*/bs_shoutbox (sb_page_id);