<?php
$magicWords = array();

$magicWords['en'] = array(
	'bs_noshoutbox' => array( 0, '__NOSHOUTBOX__', '__NO_SHOUTBOX__' ),
);

$magicWords['de'] = array(
	'bs_noshoutbox' => array( 0, '__KEINESHOUTBOX__', '__KEINE_SHOUTBOX__' ),
);