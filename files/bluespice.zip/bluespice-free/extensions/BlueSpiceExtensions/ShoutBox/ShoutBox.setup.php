<?php
wfLoadExtension( 'BlueSpiceExtensions/ShoutBox' );