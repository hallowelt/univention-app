<?php
$specialPageAliases = array();

/** English */
$specialPageAliases['en'] = array(
	'UserManager' => array( 'UserManager', 'User Manager' ),
);

/** German (Deutsch) */
$specialPageAliases['de'] = array(
	'UserManager' => array( 'UserManager', 'User Manager', 'Benutzerverwaltung', 'Benutzer Verwaltung' ),
);
