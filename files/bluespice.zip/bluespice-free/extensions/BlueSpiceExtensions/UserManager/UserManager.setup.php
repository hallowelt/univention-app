<?php
wfLoadExtension( 'BlueSpiceExtensions/UserManager' );
