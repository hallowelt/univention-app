<?php
$specialPageAliases = array();

/** English */
$specialPageAliases['en'] = array(
	'Blog' => array( 'Blog' ),
);

/** German (Deutsch) */
$specialPageAliases['de'] = array(
	'Blog' => array( 'Blog' ),
);
