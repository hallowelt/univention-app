<?php
wfLoadExtension( 'BlueSpiceExtensions/Blog' );