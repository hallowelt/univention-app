<?php

wfLoadExtension( 'BlueSpiceExtensions/AboutBlueSpice' );

