<?php
wfLoadExtension( 'BlueSpiceExtensions/GroupManager' );