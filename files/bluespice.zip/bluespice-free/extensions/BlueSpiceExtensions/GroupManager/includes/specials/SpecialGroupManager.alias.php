<?php
$specialPageAliases = array();

/** English */
$specialPageAliases['en'] = array(
	'GroupManager' => array( 'GroupManager', 'Group Manager' ),
);

/** German (Deutsch) */
$specialPageAliases['de'] = array(
	'GroupManager' => array( 'GroupManager', 'Group Manager', 'Gruppenverwaltung', 'Gruppenmanager' ),
);
