<?php
wfLoadExtension( 'BlueSpiceExtensions/NamespaceCss' );