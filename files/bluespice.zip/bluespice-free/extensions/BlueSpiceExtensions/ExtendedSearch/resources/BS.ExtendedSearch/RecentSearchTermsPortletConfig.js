Ext.define( 'BS.ExtendedSearch.RecentSearchTermsPortletConfig', {
	extend: 'BS.portal.PortletConfig',
	showItemCount: true,
	showTimeSpan: true
});