<?php

wfLoadExtension( 'BlueSpiceExtensions/CSyntaxHighlight' );