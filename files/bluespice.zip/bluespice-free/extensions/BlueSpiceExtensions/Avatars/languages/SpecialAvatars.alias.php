<?php
$specialPageAliases = array();

/** English */
$specialPageAliases['en'] = array(
    'Avatars' => array( 'Avatars', 'Avatars' ),
);

/** German (Deutsch) */
$specialPageAliases['de'] = array(
	'Avatars' => array( 'Avatare' ),
);

/** German (Deutsch) */
$specialPageAliases['de-formal'] = array(
	'Avatars' => array( 'Avatare' ),
);
