<?php

wfLoadExtension( 'BlueSpiceExtensions/Avatars' );