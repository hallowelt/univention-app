<?php

if ( file_exists( "$IP/LocalSettings.local.php" ) ) {
	require_once "$IP/LocalSettings.local.php";
}
