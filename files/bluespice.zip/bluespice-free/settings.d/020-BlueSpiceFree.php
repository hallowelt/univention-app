<?php

require_once "$IP/extensions/BlueSpiceFoundation/BlueSpiceFoundation.php";
require_once "$IP/extensions/BlueSpiceExtensions/BlueSpiceExtensions.php";
require_once "$IP/extensions/BlueSpiceTagCloud/BlueSpiceTagCloud.php";
require_once "$IP/skins/BlueSpiceSkin/BlueSpiceSkin.php";
