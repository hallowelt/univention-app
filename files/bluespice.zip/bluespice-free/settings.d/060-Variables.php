<?php
require_once( "$IP/extensions/Variables/Variables.php" );
