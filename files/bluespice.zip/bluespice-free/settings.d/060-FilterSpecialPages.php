<?php
wfLoadExtension('FilterSpecialPages');
